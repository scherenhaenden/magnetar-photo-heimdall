---
name: Magnetar Photo Heimdall
colors:
  surface: '#051424'
  surface-dim: '#051424'
  surface-bright: '#2c3a4c'
  surface-container-lowest: '#010f1f'
  surface-container-low: '#0d1c2d'
  surface-container: '#122131'
  surface-container-high: '#1c2b3c'
  surface-container-highest: '#273647'
  on-surface: '#d4e4fa'
  on-surface-variant: '#bac9cc'
  inverse-surface: '#d4e4fa'
  inverse-on-surface: '#233143'
  outline: '#849396'
  outline-variant: '#3b494c'
  surface-tint: '#00daf3'
  primary: '#c3f5ff'
  on-primary: '#00363d'
  primary-container: '#00e5ff'
  on-primary-container: '#00626e'
  inverse-primary: '#006875'
  secondary: '#bcc7de'
  on-secondary: '#263143'
  secondary-container: '#3e495d'
  on-secondary-container: '#aeb9d0'
  tertiary: '#e8ecff'
  on-tertiary: '#283044'
  tertiary-container: '#c8d0ea'
  on-tertiary-container: '#51596f'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#9cf0ff'
  primary-fixed-dim: '#00daf3'
  on-primary-fixed: '#001f24'
  on-primary-fixed-variant: '#004f58'
  secondary-fixed: '#d8e3fb'
  secondary-fixed-dim: '#bcc7de'
  on-secondary-fixed: '#111c2d'
  on-secondary-fixed-variant: '#3c475a'
  tertiary-fixed: '#dae2fd'
  tertiary-fixed-dim: '#bec6e0'
  on-tertiary-fixed: '#131b2e'
  on-tertiary-fixed-variant: '#3f465c'
  background: '#051424'
  on-background: '#d4e4fa'
  surface-variant: '#273647'
typography:
  headline-lg:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '600'
    lineHeight: '1.2'
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.3'
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '600'
    lineHeight: '1.4'
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.5'
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: '1.5'
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: '1.4'
  data-mono:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '500'
    lineHeight: '1.4'
  label-caps:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '700'
    lineHeight: '1.2'
    letterSpacing: 0.08em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 4px
  sidebar-width: 260px
  topbar-height: 64px
  gutter: 16px
  margin-page: 24px
  grid-gap: 12px
---

## Brand & Style

The design system is engineered for professional photographers and digital asset managers who require extreme precision and high-density information. The aesthetic is "Mission Control"—a fusion of high-end creative tools and technical monitoring systems. 

The style is **Minimalist-Professional** with a focus on dark, high-contrast surfaces that allow the photographs to remain the singular point of chromatic focus. It avoids decorative elements in favor of functional clarity, utilizing subtle tonal layering and crisp, linear iconography to convey a sense of absolute reliability and technical sophistication. The emotional response is one of calm, focused control over vast data landscapes.

## Colors

The palette is anchored by a deep blue-black graphite (`#0B1016`) which serves as the canvas for the entire application. This maximizes perceived contrast for photo editing and viewing.

- **Primary (Electric Cyan):** Reserved strictly for active states, primary actions, and successful connections. It provides a sharp, technological "glow" against the dark background.
- **Surface Hierarchy:** Uses increments of bluish-gray to define depth. The Sidebar and Top Bar use slightly lighter or more saturated variations of the background to create structural separation without the need for heavy borders.
- **Functional Colors:** Green, Amber, and Muted Red are used sparingly for system health, thermal warnings, and destructive actions. These are desaturated slightly to maintain the "Professional" atmosphere and prevent them from competing with the imagery.

## Typography

This design system utilizes **Inter** exclusively to maintain a clean, systematic appearance. 

- **Data Presentation:** For all technical metadata (file sizes, hashes, timestamps, and coordinates), the `data-mono` style must be used. It leverages Inter's OpenType features (`tnum` for tabular numbers) to ensure columns of data align perfectly in tables.
- **Hierarchy:** High-level navigation uses bold headlines, while technical attributes use `label-caps` for clear categorization.
- **Scaling:** On desktop, the density is kept high; font sizes rarely exceed 32px to ensure more data is visible on screen at once.

## Layout & Spacing

The layout follows a **Fixed-Fluid hybrid model** designed for large desktop monitors.

- **Sidebar:** A fixed 260px left-hand navigation panel. It uses a dark bluish-gray surface to separate library management from the workspace.
- **Top Bar:** A fixed 64px header containing breadcrumbs and global search. It should be semi-transparent with a backdrop-blur to suggest depth.
- **The Grid:** A high-density fluid grid for photo thumbnails. The gap is kept tight (12px) to maximize the number of assets on screen.
- **Data Tables:** Use a 40px row height for high-density information display, allowing for 20+ rows to be visible without scrolling on standard displays.

## Elevation & Depth

Visual hierarchy is achieved through **Tonal Layering** rather than traditional shadows.

- **Level 0 (Base):** The main background (`#0B1016`).
- **Level 1 (Navigation/Sidebar):** A slightly lighter tint (`#161D26`) to define structural boundaries.
- **Level 2 (Active Elements/Modals):** A third tier of dark gray with a subtle 1px stroke (`#1E293B`) to define floating panels or popovers.
- **Outlines:** Use low-contrast "Ghost Borders" (1px solid, 10% white opacity) to define elements like input fields and card boundaries without adding visual noise.
- **Overlays:** Modals and context menus should use a 20px backdrop blur to maintain the premium, glass-like feel of high-end software.

## Shapes

The design system uses a consistent **Rounded** language (8px - 12px) to soften the technical nature of the app and make it feel approachable as a creative tool.

- **Small Components:** Checkboxes and small buttons use a 4px radius.
- **Standard Components:** Buttons, Input fields, and photo thumbnails use an 8px radius.
- **Containers:** Modals and large surface areas use a 12px radius.
- **Status Pills:** Badges for health or thermal status should be fully rounded (pill-shaped) to distinguish them from interactive buttons.

## Components

- **Buttons:** Primary buttons are solid Electric Cyan with black text. Secondary buttons use a ghost style (1px border) with cyan text.
- **Metadata Badges:** Small, semi-transparent overlays on photo thumbnails. Use `data-mono` typography. Backgrounds for badges should be `rgba(0, 0, 0, 0.6)`.
- **Sidebar Nav:** Items use a vertical indicator bar (2px wide) in Electric Cyan on the left side when active.
- **Status Indicators:** 
    - **Thermal:** A small bar graph or dot using the Warning (Amber) or Danger (Red) colors.
    - **Health:** A "Pulse" animation on a 6px dot for active server connections.
- **Input Fields:** Dark background (`#0F172A`) with a subtle border. On focus, the border transitions to Electric Cyan.
- **Progress Bars:** Thin (4px) bars. Use a subtle glow effect (box-shadow with spread) in Electric Cyan for active operations like "Generating Previews" or "Syncing SSH".
- **Iconography:** All icons must be linear, 1.5px stroke width. Never use filled icons unless it represents a toggle-on state.